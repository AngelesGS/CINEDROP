package com.example.proyectofinal;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.google.android.material.button.MaterialButton;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PeliculaAdapter extends RecyclerView.Adapter<PeliculaAdapter.ViewHolder> {

    private List<Pelicula> listaPeliculas;
    private OnItemClickListener listener;
    private String token;
    private Set<Integer> favoritosIds = new HashSet<>();

    public interface OnItemClickListener {
        void onItemClick(Pelicula pelicula);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public PeliculaAdapter(List<Pelicula> listaPeliculas, String token) {
        this.listaPeliculas = listaPeliculas;
        this.token = token;
    }

    public void setFavoritos(Set<Integer> favoritosIds) {
        this.favoritosIds = favoritosIds;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_pelicula, parent, false);
        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Pelicula peli = listaPeliculas.get(position);
        Context context = holder.itemView.getContext();

        holder.txtTitulo.setText(peli.getTitulo());
        Glide.with(context).load(peli.getUrlImagen()).into(holder.imgPoster);

        // Lógica de carga de favoritos usando IDs
        if (favoritosIds.contains(peli.getId())) {
            holder.btnLikePelicula.setImageResource(android.R.drawable.btn_star_big_on);
        } else {
            holder.btnLikePelicula.setImageResource(android.R.drawable.btn_star_big_off);
        }

        // Click en la estrella para alternar favoritos en el SERVIDOR
        holder.btnLikePelicula.setOnClickListener(v -> {
            ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
            FavoritoBody body = new FavoritoBody(peli.getId());
            
            // IMPORTANTE: Aseguramos el prefijo Bearer para que Slim/JWT lo reconozca
            String authToken = (token != null && !token.startsWith("Bearer ")) ? "Bearer " + token : token;

            if (favoritosIds.contains(peli.getId())) {
                // Ya es favorito, lo eliminamos
                apiService.eliminarFavorito(authToken, body).enqueue(new Callback<RespuestaBasica>() {
                    @Override
                    public void onResponse(Call<RespuestaBasica> call, Response<RespuestaBasica> response) {
                        if (response.isSuccessful()) {
                            favoritosIds.remove(peli.getId());
                            holder.btnLikePelicula.setImageResource(android.R.drawable.btn_star_big_off);
                            Toast.makeText(context, "Eliminado de favoritos", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Error al eliminar: " + response.code(), Toast.LENGTH_SHORT).show();
                            Log.e("API_FAV", "Error: " + response.code());
                        }
                    }
                    @Override
                    public void onFailure(Call<RespuestaBasica> call, Throwable t) {
                        Toast.makeText(context, "Error de red", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                // No es favorito, lo agregamos
                apiService.agregarFavorito(authToken, body).enqueue(new Callback<RespuestaBasica>() {
                    @Override
                    public void onResponse(Call<RespuestaBasica> call, Response<RespuestaBasica> response) {
                        if (response.isSuccessful()) {
                            favoritosIds.add(peli.getId());
                            holder.btnLikePelicula.setImageResource(android.R.drawable.btn_star_big_on);
                            Toast.makeText(context, "Agregado a favoritos", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Error al agregar: " + response.code(), Toast.LENGTH_SHORT).show();
                            Log.e("API_FAV", "Error: " + response.code());
                        }
                    }
                    @Override
                    public void onFailure(Call<RespuestaBasica> call, Throwable t) {
                        Toast.makeText(context, "Error de red", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        holder.btnVerPelicula.setOnClickListener(v -> { if (listener != null) listener.onItemClick(peli); });
        holder.imgPoster.setOnClickListener(v -> { if (listener != null) listener.onItemClick(peli); });
    }

    @Override
    public int getItemCount() { return listaPeliculas != null ? listaPeliculas.size() : 0; }

    public void actualizarLista(List<Pelicula> nuevaLista) {
        this.listaPeliculas = nuevaLista;
        notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtTitulo;
        ImageView imgPoster, btnLikePelicula;
        MaterialButton btnVerPelicula;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitulo = itemView.findViewById(R.id.txtTituloPelicula);
            imgPoster = itemView.findViewById(R.id.imgPoster);
            btnLikePelicula = itemView.findViewById(R.id.btnLikePelicula);
            btnVerPelicula = itemView.findViewById(R.id.btnVerPelicula);
        }
    }
}