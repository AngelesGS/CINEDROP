package com.example.proyectofinal;

public class UsuarioReenviar {
    private String email;

    public UsuarioReenviar(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
