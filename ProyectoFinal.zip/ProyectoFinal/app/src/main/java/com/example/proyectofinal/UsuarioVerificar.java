package com.example.proyectofinal;

public class UsuarioVerificar {
    private String email;
    private String codigo;

    public UsuarioVerificar(String email,String codigo) {
        this.email = email;
        this.codigo = codigo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
