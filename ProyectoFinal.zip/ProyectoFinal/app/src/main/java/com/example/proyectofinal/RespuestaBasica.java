package com.example.proyectofinal;

public class RespuestaBasica {
    private String message;

    public String getMessage() {
        return message;
    }
}
