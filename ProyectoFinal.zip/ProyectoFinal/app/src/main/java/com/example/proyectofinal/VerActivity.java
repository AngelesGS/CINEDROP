package com.example.proyectofinal;

import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class VerActivity extends AppCompatActivity {

    private PlayerView playerView;
    private ExoPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_ver);

        playerView = findViewById(R.id.playerView);
        TextView txtTitulo = findViewById(R.id.txtTitulo);
        ImageView btnAtras = findViewById(R.id.btnAtras);

        btnAtras.setOnClickListener(v -> finish());

        String titulo = getIntent().getStringExtra("titulo");
        String url = getIntent().getStringExtra("urlpelicula");

        if (titulo != null) txtTitulo.setText(titulo);
        if (url != null) inicializarReproductor(url);
    }

    private void inicializarReproductor(String url) {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(url));
        player.prepare();
        player.play();
    }

    @Override protected void onPause() { super.onPause(); if (player != null) player.pause(); }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (player != null) { player.release(); player = null; }
    }
}
