package com.example.proyectofinal;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class PeliculaRespuesta {
    private String status;
    private String message;
    private List<PeliculaTodas> data;

    public PeliculaRespuesta() {
    }

    public List<PeliculaTodas> getData() {
        return data;
    }
    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}
