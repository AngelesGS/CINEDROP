package com.example.proyectofinal;

import com.google.gson.annotations.SerializedName;

public class PeliculaComprada {

    private int id_compra;
    private String fecha_compra;
    private int id_pelicula;
    private String nombre;
    private String genero;
    @SerializedName("pelicula_link")
    private String peliculaLink;

    @SerializedName("portada_link")
    private String portadaLink;

    public PeliculaComprada() {
    }

    public int getId_compra() {
        return id_compra;
    }

    public void setId_compra(int id_compra) {
        this.id_compra = id_compra;
    }

    public String getFecha_compra() {
        return fecha_compra;
    }

    public void setFecha_compra(String fecha_compra) {
        this.fecha_compra = fecha_compra;
    }

    public int getId_pelicula() {
        return id_pelicula;
    }

    public void setId_pelicula(int id_pelicula) {
        this.id_pelicula = id_pelicula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPortada_link() {
        return portadaLink;
    }

    public void setPortada_link(String portada_link) {
        this.portadaLink = portada_link;
    }

    public String getPelicula_link() {
        return peliculaLink;
    }

    public void setPelicula_link(String pelicula_link) {
        this.peliculaLink = pelicula_link;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }
}
