package com.example.proyectofinal;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class SoporteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soporte);

        ImageButton btnVolver = findViewById(R.id.btnVolver);
        MaterialButton btnEnviarCorreo = findViewById(R.id.btnEnviarCorreo);

        btnVolver.setOnClickListener(v -> finish());

        btnEnviarCorreo.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("mailto:"));
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"soporte@cinedrop.com"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Soporte Técnico - CineDrop");
            intent.putExtra(Intent.EXTRA_TEXT, "Escribe aquí tu problema detallado:\n\n");

            try {
                startActivity(Intent.createChooser(intent, "Selecciona una aplicación de correo"));
            } catch (Exception e) {
                Toast.makeText(SoporteActivity.this, "No tienes una app de correo instalada", Toast.LENGTH_SHORT).show();
            }
        });
    }
}