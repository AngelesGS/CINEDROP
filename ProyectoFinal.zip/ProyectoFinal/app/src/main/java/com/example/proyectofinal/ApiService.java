package com.example.proyectofinal;
import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Header;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.GET;
import retrofit2.http.PUT;
import retrofit2.http.Query;


public interface ApiService {
    @Headers("Content-Type: application/json")
    @POST("api/usuarios/registro")
    Call<RespuestaBasica> registrarUsuario(@Body UsuarioRegistro nuevoUsuario);
    @Headers("Content-Type: application/json")
    @POST("api/usuarios/login")
    Call<LoginRespuesta> loginUsuario(@Body UsuarioLogin usuarioLogin);
    @Headers("Content-Type: application/json")
    @POST("api/usuarios/verificar")
    Call<RespuestaBasica> verificarUsuario(@Body UsuarioVerificar usuarioVerificar);
    @Headers("Content-Type: application/json")
    @POST("api/usuarios/reenviar_correo")
    Call<RespuestaBasica> reenviarUsuario(@Body UsuarioReenviar usuarioReenviar);
    @Headers("Content-Type: application/json")
    @POST("api/usuarios/actualizar_perfil")
    Call<UsuarioCambiarNo> actualizarPerfil(@Body UsuarioActualizar body);
    @Headers("Content-Type: application/json")
    @GET("api/usuarios/validar")
    Call<UsuarioRespuesta> validarToken(@Header("Authorization") String token);
    @Headers("Content-Type: application/json")
    @GET("api/pelicula/mostrar_peliculas")
    Call<PeliculaRespuesta> obtenerPeliculas(@Query("limite") Integer limite, @Query("offset") Integer offset);

    @Headers("Content-Type: application/json")
    @POST("api/usuarios/favoritos/agregar")
    Call<RespuestaBasica> agregarFavorito(@Header("Authorization") String token, @Body FavoritoBody favorito);

    @Headers("Content-Type: application/json")
    @POST("api/usuarios/favoritos/eliminar")
    Call<RespuestaBasica> eliminarFavorito(@Header("Authorization") String token, @Body FavoritoBody favorito);

    @Headers("Content-Type: application/json")
    @GET("api/usuarios/favoritos/listar")
    Call<PeliculaRespuesta> obtenerFavoritos(@Header("Authorization") String token);
}
