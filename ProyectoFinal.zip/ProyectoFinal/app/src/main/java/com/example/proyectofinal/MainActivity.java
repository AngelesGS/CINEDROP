package com.example.proyectofinal;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.PopupMenu;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private TextView UsuarioMenu, txtSeccionCat, txtHeroTitle;
    private RecyclerView recyclerViewPeliculas, recyclerViewGeneros;
    private BottomNavigationView bottomNavegacion;
    private CardView cardHeroMovie;
    private MaterialButton btnVerAhora;

    private ImageView IVimgHero;
    private ImageButton btnAtras;

    private List<Pelicula> listaOriginal = new ArrayList<>();
    private Set<Integer> favoritosIds = new HashSet<>();
    private PeliculaAdapter adapter;
    private String token, linkVideoHero = "", tituloHero = "Pulse (Kairo)",ImgHero;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vincularVistas();
        configurarRecyclers();

        SharedPreferences pref = getSharedPreferences("MisPreferencias", MODE_PRIVATE);
        token = pref.getString("token_jwt", null);
        UsuarioMenu.setText("Hola, " + obtenerNombreDelToken(token) + " ▼");

        apiService = RetrofitClient.getClient().create(ApiService.class);
        
        cargarDatosIniciales();

        btnVerAhora.setOnClickListener(v -> lanzarReproductor(tituloHero, linkVideoHero));
        btnAtras.setOnClickListener(v -> gestionarVistas(false, true, false));
        UsuarioMenu.setOnClickListener(this::mostrarMenuUsuario);

        bottomNavegacion.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_descubrir) gestionarVistas(true, false, true);
            else if (id == R.id.nav_genero) gestionarVistas(false, true, false);
            else if (id == R.id.nav_coleccion) gestionarVistas(false, false, true);
            return true;
        });
    }

    private void vincularVistas() {
        UsuarioMenu = findViewById(R.id.UsuarioMenu);
        recyclerViewPeliculas = findViewById(R.id.recyclerViewPeliculas);
        recyclerViewGeneros = findViewById(R.id.recyclerViewGeneros);
        bottomNavegacion = findViewById(R.id.bottomNavegacion);
        txtSeccionCat = findViewById(R.id.txtSeccionCat);
        cardHeroMovie = findViewById(R.id.cardHeroMovie);
        IVimgHero = findViewById(R.id.imgHero);
        btnVerAhora = findViewById(R.id.btnVerAhora);
        txtHeroTitle = findViewById(R.id.txtHeroTitle);
        btnAtras = findViewById(R.id.btnAtras);
        if (txtHeroTitle != null) txtHeroTitle.setText(tituloHero);
    }

    private void configurarRecyclers() {
        recyclerViewPeliculas.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerViewGeneros.setLayoutManager(new GridLayoutManager(this, 2));
        configurarRejillaGeneros();
    }

    private void gestionarVistas(boolean mostrarHero, boolean mostrarGeneros, boolean mostrarLista) {
        cardHeroMovie.setVisibility(mostrarHero ? View.VISIBLE : View.GONE);
        recyclerViewGeneros.setVisibility(mostrarGeneros ? View.VISIBLE : View.GONE);
        recyclerViewPeliculas.setVisibility(mostrarLista ? View.VISIBLE : View.GONE);
        txtSeccionCat.setVisibility(mostrarLista ? View.VISIBLE : View.GONE);
        btnAtras.setVisibility(View.GONE);

        if (mostrarHero) {
            txtSeccionCat.setText("Catálogo Disponible");
            if (adapter != null) adapter.actualizarLista(listaOriginal);
        } else if (!mostrarGeneros && mostrarLista) {
            txtSeccionCat.setText("Mi Colección");
            filtrarFavoritos();
        }
    }

    private void cargarDatosIniciales() {
        // Cargar Favoritos
        apiService.obtenerFavoritos(token).enqueue(new Callback<PeliculaRespuesta>() {
            @Override
            public void onResponse(Call<PeliculaRespuesta> call, Response<PeliculaRespuesta> response) {
                if (response.isSuccessful() && response.body() != null && response.body().getData() != null) {
                    for (PeliculaTodas p : response.body().getData()) favoritosIds.add(p.getId());
                    if (adapter != null) adapter.setFavoritos(favoritosIds);
                }
            }
            @Override
            public void onFailure(Call<PeliculaRespuesta> call, Throwable t) {}
        });

        // Cargar Películas
        apiService.obtenerPeliculas(30, 0).enqueue(new Callback<PeliculaRespuesta>() {
            @Override
            public void onResponse(Call<PeliculaRespuesta> call, Response<PeliculaRespuesta> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<PeliculaTodas> data = response.body().getData();
                    listaOriginal.clear();
                    for (PeliculaTodas p : data) {
                        listaOriginal.add(new Pelicula(p.getId(), p.getNombre(), p.getGenero(), p.getPortadaLink(), p.getPeliculaLink()));
                        if (p.getNombre().equalsIgnoreCase(tituloHero)) {
                            linkVideoHero = p.getPeliculaLink();
                            ImgHero = p.getPortadaLink();
                            if (IVimgHero != null) Glide.with(MainActivity.this).load(ImgHero).into(IVimgHero);
                        }
                    }
                    adapter = new PeliculaAdapter(new ArrayList<>(listaOriginal), token);
                    adapter.setFavoritos(favoritosIds);
                    recyclerViewPeliculas.setAdapter(adapter);
                    adapter.setOnItemClickListener(p -> lanzarReproductor(p.getTitulo(), p.getUrlPelicula()));
                }
            }
            @Override
            public void onFailure(Call<PeliculaRespuesta> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Error de conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarMenuUsuario(View v) {
        PopupMenu popup = new PopupMenu(this, v, 0, 0, R.style.PopupStyleOscuro);
        popup.getMenuInflater().inflate(R.menu.menu_usuario, popup.getMenu());
        
        // Hack sencillo para iconos
        try {
            java.lang.reflect.Field f = popup.getClass().getDeclaredField("mPopup");
            f.setAccessible(true);
            Object helper = f.get(popup);
            helper.getClass().getDeclaredMethod("setForceShowIcon", boolean.class).invoke(helper, true);
        } catch (Exception ignored) {}

        popup.setOnMenuItemClickListener(item -> {
            int id = item.getItemId();
            if (id == R.id.configuracion) startActivity(new Intent(this, ConfiguracionActivity.class));
            else if (id == R.id.soporte_app) startActivity(new Intent(this, SoporteActivity.class));
            else if (id == R.id.cerrar_sesion) cerrarSesion();
            return true;
        });
        popup.show();
    }

    private void cerrarSesion() {
        getSharedPreferences("MisPreferencias", MODE_PRIVATE).edit().remove("token_jwt").apply();
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void configurarRejillaGeneros() {
        String[] generos = {"Acción", "Animación", "Aventura", "Ciencia Ficción", "Comedia", "Drama", "Terror", "Suspenso"};
        int[] colores = {0xFF2E0854, 0xFF7C3AED, 0xFF1E3A8A, 0xFF3B82F6, 0xFF065F46, 0xFF10B981, 0xFF881337, 0xFFF43F5E};

        recyclerViewGeneros.setAdapter(new RecyclerView.Adapter<GeneroViewHolder>() {
            @NonNull @Override public GeneroViewHolder onCreateViewHolder(@NonNull ViewGroup p, int t) {
                return new GeneroViewHolder(LayoutInflater.from(p.getContext()).inflate(R.layout.item_genero_tarjeta, p, false));
            }
            @Override public void onBindViewHolder(@NonNull GeneroViewHolder h, int pos) {
                h.txtNombre.setText(generos[pos]);
                GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{colores[pos % colores.length], 0xFF111827});
                h.contenedor.setBackground(gd);
                h.itemView.setOnClickListener(v -> {
                    gestionarVistas(false, false, true);
                    btnAtras.setVisibility(View.VISIBLE);
                    txtSeccionCat.setText("Resultados: " + generos[pos]);
                    filtrarPorGenero(generos[pos]);
                });
            }
            @Override public int getItemCount() { return generos.length; }
        });
    }

    private void filtrarPorGenero(String genero) {
        List<Pelicula> filtrada = new ArrayList<>();
        for (Pelicula p : listaOriginal) if (p.getGenero().equalsIgnoreCase(genero)) filtrada.add(p);
        if (adapter != null) adapter.actualizarLista(filtrada);
    }

    private void filtrarFavoritos() {
        List<Pelicula> favs = new ArrayList<>();
        for (Pelicula p : listaOriginal) if (favoritosIds.contains(p.getId())) favs.add(p);
        if (adapter != null) adapter.actualizarLista(favs);
    }

    private void lanzarReproductor(String t, String u) {
        if (u == null || u.isEmpty()) {
            Toast.makeText(this, "Video no disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, VerActivity.class);
        i.putExtra("titulo", t);
        i.putExtra("urlpelicula", u);
        startActivity(i);
    }

    private String obtenerNombreDelToken(String token) {
        if (token == null || !token.contains(".")) return "Usuario";
        try {
            String payload = new String(Base64.decode(token.split("\\.")[1], Base64.URL_SAFE));
            return new JSONObject(payload).getJSONObject("data").getString("nombre");
        } catch (Exception e) { return "Usuario"; }
    }

    private static class GeneroViewHolder extends RecyclerView.ViewHolder {
        TextView txtNombre; FrameLayout contenedor;
        public GeneroViewHolder(@NonNull View v) {
            super(v);
            txtNombre = v.findViewById(R.id.txtNombreGenero);
            contenedor = v.findViewById(R.id.contenedorGradiente);
        }
    }
}
