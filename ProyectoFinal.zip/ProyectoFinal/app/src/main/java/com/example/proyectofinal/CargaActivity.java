package com.example.proyectofinal;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CargaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carga);

        ImageView logo = findViewById(R.id.logo_carga);
        if (logo != null) {
            logo.setAlpha(0f);
            logo.animate().alpha(1f).scaleX(1.2f).scaleY(1.2f).setDuration(1500).start();
        }

        String token = getSharedPreferences("MisPreferencias", MODE_PRIVATE).getString("token_jwt", "");

        if (token.isEmpty()) {
            new Handler(Looper.getMainLooper()).postDelayed(this::irALogin, 2500);
        } else {
            verificarToken(token);
        }
    }

    private void verificarToken(String token) {
        RetrofitClient.getClient().create(ApiService.class).validarToken("Bearer " + token)
                .enqueue(new Callback<UsuarioRespuesta>() {
            @Override
            public void onResponse(Call<UsuarioRespuesta> call, Response<UsuarioRespuesta> response) {
                if (response.isSuccessful()) {
                    startActivity(new Intent(CargaActivity.this, MainActivity.class));
                    finish();
                } else {
                    irALogin();
                }
            }
            @Override public void onFailure(Call<UsuarioRespuesta> call, Throwable t) { irALogin(); }
        });
    }

    private void irALogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }
}
