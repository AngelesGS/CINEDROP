package com.example.proyectofinal;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import com.google.android.material.snackbar.Snackbar;
import org.json.JSONObject;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ConfiguracionActivity extends AppCompatActivity {

    private Button btnEditarPerfil, btnGuardar, btnCancelar;
    private EditText etNombre, etCorreo, etPassword;
    private LinearLayout layoutAcciones;
    private boolean estaEditando = false;
    private String nombreOriginal = "Usuario", correoOriginal = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuracion);

        vincularVistas();
        cargarDatosToken();
        configurarBotones();
    }

    private void vincularVistas() {
        etNombre = findViewById(R.id.editTextNombre);
        etCorreo = findViewById(R.id.editTextCorreo);
        etPassword = findViewById(R.id.editTextPassword);
        layoutAcciones = findViewById(R.id.layoutAcciones);
        btnEditarPerfil = findViewById(R.id.btnEditarPerfil);
        btnGuardar = findViewById(R.id.btnGuardarEdicion);
        btnCancelar = findViewById(R.id.btnCancelarEdicion);
    }

    private void cargarDatosToken() {
        String token = getSharedPreferences("MisPreferencias", MODE_PRIVATE).getString("token_jwt", null);
        if (token != null && token.contains(".")) {
            try {
                String payload = new String(Base64.decode(token.split("\\.")[1], Base64.URL_SAFE));
                JSONObject data = new JSONObject(payload).getJSONObject("data");
                nombreOriginal = data.optString("nombre", "Usuario");
                correoOriginal = data.optString("correo", data.optString("email", ""));
            } catch (Exception e) { Log.e("CONFIG", "Error token: " + e.getMessage()); }
        }
        etNombre.setText(nombreOriginal);
        etCorreo.setText(correoOriginal);
    }

    private void configurarBotones() {
        findViewById(R.id.btnAtras).setOnClickListener(v -> finish());
        btnEditarPerfil.setOnClickListener(v -> conmutarEdicion(true));
        btnCancelar.setOnClickListener(v -> {
            etNombre.setText(nombreOriginal);
            etPassword.setText("");
            conmutarEdicion(false);
        });

        btnGuardar.setOnClickListener(v -> {
            String nuevoNombre = etNombre.getText().toString().trim();
            String nuevoPassword = etPassword.getText().toString().trim();


            if (nuevoNombre.isEmpty() && nuevoPassword.isEmpty()) return;

            btnGuardar.setEnabled(false);
            btnGuardar.setText("...");

            ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
            apiService.actualizarPerfil(new UsuarioActualizar(correoOriginal,nuevoNombre,nuevoPassword)).enqueue(new Callback<UsuarioCambiarNo>() {
                @Override
                public void onResponse(Call<UsuarioCambiarNo> call, Response<UsuarioCambiarNo> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        String nuevoToken = response.body().getToken();
                        if (nuevoToken != null && !nuevoToken.isEmpty()) {
                            getSharedPreferences("MisPreferencias", MODE_PRIVATE)
                                    .edit()
                                    .putString("token_jwt", nuevoToken)
                                    .apply();
                        }

                        if (!nuevoNombre.isEmpty()) {
                            nombreOriginal = nuevoNombre;
                        }
                        etPassword.setText("");
                        conmutarEdicion(false);
                        mostrarAviso("¡Perfil actualizado correctamente!");
                    } else {
                        mostrarAviso("Error al guardar en la base de datos");
                    }
                    btnGuardar.setEnabled(true);
                    btnGuardar.setText("Guardar");
                }

                @Override
                public void onFailure(Call<UsuarioCambiarNo> call, Throwable t) {
                    btnGuardar.setEnabled(true);
                    btnGuardar.setText("Guardar");
                    mostrarAviso("Error de conexión");
                    Log.e("API_ERROR", "Fallo real de Retrofit: " + t.getMessage());
                }
            });
        });
    }

    private void conmutarEdicion(boolean activar) {
        estaEditando = activar;
        etNombre.setEnabled(activar);
        etPassword.setEnabled(activar);
        etNombre.setAlpha(activar ? 1.0f : 0.6f);
        etPassword.setAlpha(activar ? 1.0f : 0.6f);
        layoutAcciones.setVisibility(activar ? View.VISIBLE : View.GONE);
        btnEditarPerfil.setText(activar ? "Editando..." : "Desbloquear Perfil");
        int icono = activar ? android.R.drawable.ic_menu_edit : android.R.drawable.ic_secure;
        btnEditarPerfil.setCompoundDrawablesWithIntrinsicBounds(icono, 0, 0, 0);
    }

    private void mostrarAviso(String msg) {
        Snackbar snack = Snackbar.make(findViewById(android.R.id.content), msg, Snackbar.LENGTH_SHORT);
        snack.getView().setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
        snack.show();
    }
}
