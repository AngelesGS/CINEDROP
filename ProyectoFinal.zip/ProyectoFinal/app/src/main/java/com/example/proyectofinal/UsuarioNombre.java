package com.example.proyectofinal;

public class UsuarioNombre {
    private String email;
    private String nombre;

    public UsuarioNombre(String email,String nombre) {
        this.email = email;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
