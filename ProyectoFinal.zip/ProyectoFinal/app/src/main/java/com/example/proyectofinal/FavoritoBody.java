package com.example.proyectofinal;

import com.google.gson.annotations.SerializedName;

public class FavoritoBody {
    @SerializedName("pelicula_id")
    private int peliculaId;

    public FavoritoBody(int peliculaId) {
        this.peliculaId = peliculaId;
    }

    public int getPeliculaId() {
        return peliculaId;
    }
}
