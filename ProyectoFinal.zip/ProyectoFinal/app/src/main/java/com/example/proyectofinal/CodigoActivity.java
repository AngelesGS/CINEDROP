package com.example.proyectofinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CodigoActivity extends AppCompatActivity {

    private EditText etCodigo;
    private ApiService apiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_codigo);

        String email = getIntent().getStringExtra("Usuarioemail");
        etCodigo = findViewById(R.id.editTextCodigo);
        Button btnVerificar = findViewById(R.id.btnVerificar);
        Button btnReenviar = findViewById(R.id.btnReenviarCodigo);

        apiService = RetrofitClient.getClient().create(ApiService.class);

        btnVerificar.setOnClickListener(v -> verificar(email));
        btnReenviar.setOnClickListener(v -> reenviar(email));
    }

    private void reenviar(String email) {
        apiService.reenviarUsuario(new UsuarioReenviar(email)).enqueue(new Callback<RespuestaBasica>() {
            @Override
            public void onResponse(Call<RespuestaBasica> call, Response<RespuestaBasica> response) {
                Toast.makeText(CodigoActivity.this, response.isSuccessful() ? "Código reenviado" : "Error al reenviar", Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onFailure(Call<RespuestaBasica> call, Throwable t) {
                Toast.makeText(CodigoActivity.this, "Error de conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void verificar(String email) {
        String codigo = etCodigo.getText().toString().trim();
        if (codigo.isEmpty()) {
            Toast.makeText(this, "Ingresa el código", Toast.LENGTH_SHORT).show();
            return;
        }

        apiService.verificarUsuario(new UsuarioVerificar(email, codigo)).enqueue(new Callback<RespuestaBasica>() {
            @Override
            public void onResponse(Call<RespuestaBasica> call, Response<RespuestaBasica> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(CodigoActivity.this, "Verificado", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(CodigoActivity.this, LoginActivity.class));
                    finish();
                } else {
                    Toast.makeText(CodigoActivity.this, "Código incorrecto", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<RespuestaBasica> call, Throwable t) {
                Toast.makeText(CodigoActivity.this, "Error de conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
