package com.example.proyectofinal;

public class Pelicula {
    private int id;
    private String titulo;
    private String genero;
    private String urlImagen;
    private String urlPelicula;

    public Pelicula(int id, String titulo, String genero, String urlImagen, String urlPelicula) {
        this.id = id;
        this.titulo = titulo;
        this.genero = genero;
        this.urlImagen = urlImagen;
        this.urlPelicula = urlPelicula;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getGenero() { return genero; }
    public String getUrlImagen() { return urlImagen; }
    public String getUrlPelicula() { return urlPelicula; }
}