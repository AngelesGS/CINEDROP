package com.example.proyectofinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegistrarseActivity extends AppCompatActivity {

    private EditText etNombre, etEmail, etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        etNombre = findViewById(R.id.editTextNombre);
        etEmail = findViewById(R.id.editTextEmail);
        etPassword = findViewById(R.id.editTextPassword);
        Button btnRegistrar = findViewById(R.id.button);
        TextView txtIniciarSesion = findViewById(R.id.iniciar_sesión);

        btnRegistrar.setOnClickListener(v -> registrarUsuario());
        txtIniciarSesion.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    private void registrarUsuario() {
        String nombre = etNombre.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (nombre.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService apiService = RetrofitClient.getClient().create(ApiService.class);
        apiService.registrarUsuario(new UsuarioRegistro(nombre, email, password)).enqueue(new Callback<RespuestaBasica>() {
            @Override
            public void onResponse(Call<RespuestaBasica> call, Response<RespuestaBasica> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(RegistrarseActivity.this, "¡Registro exitoso!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegistrarseActivity.this, CodigoActivity.class);
                    intent.putExtra("Usuarioemail", email);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(RegistrarseActivity.this, "Error al registrarse", Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onFailure(Call<RespuestaBasica> call, Throwable t) {
                Toast.makeText(RegistrarseActivity.this, "Error de red", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
