package com.example.proyectofinal;

public class LoginRespuesta {
    private String token;
    private String mensaje;

    public String getToken() {
        return token;
    }
    public String getMensaje() {
        return mensaje;
    }
}
