package com.example.proyectofinal;

public class UsuarioRespuesta {
    private String message;
    private UsuarioRegistro usuarioRegistro;

    public String getMessage() {
        return message;
    }

    public UsuarioRegistro getUsuario() {
        return usuarioRegistro;
    }
}
