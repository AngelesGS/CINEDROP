package com.example.proyectofinal;

import com.google.gson.annotations.SerializedName;

public class PeliculaTodas {
    private int id;
    private String nombre;
    private String autor;
    private String descripcion;
    private double precio;
    private String idioma;
    private String genero;

    @SerializedName("pelicula_link")
    private String peliculaLink;

    @SerializedName("portada_link")
    private String portadaLink;

    public PeliculaTodas() {
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getPeliculaLink() {
        return peliculaLink;
    }

    public void setPeliculaLink(String peliculaLink) {
        this.peliculaLink = peliculaLink;
    }

    public String getPortadaLink() {
        return portadaLink;
    }
    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setPortadaLink(String portadaLink) {
        this.portadaLink = portadaLink;
    }
}
