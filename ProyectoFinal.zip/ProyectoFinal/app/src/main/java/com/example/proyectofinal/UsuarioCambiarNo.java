package com.example.proyectofinal;

public class UsuarioCambiarNo {
    private String message;
    private String token;

    public String getMessage() {
        return message;
    }
    public String getToken() {
        return token;
    }
}
